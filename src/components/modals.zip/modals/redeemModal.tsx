import { useTranslation } from 'react-i18next';
import DialogueModal from '../Dialogue'
import { useGlobalList, useLoginStore, useModalState } from '../globalFunctions/store'
import { useCouponRechareg } from '../hooks/getUserInfoHook';
import { useRef } from 'react';
import { ToastrPngk } from '../globalFunctions/toastr';
export default function RedemptioModal() {
    const { t } = useTranslation(["home", "main"]);
    const color = useGlobalList(state => state.color);
    const codeRef=useRef<any>()
    const coupinRedeem=useCouponRechareg()
    const RedStatus = useModalState((state) => state.redeem);
    function redemCoupon(){
        if(codeRef?.current.value!==""){
            const payload={
                code:codeRef?.current.value
            }
            coupinRedeem.mutate(payload)
        }
        else{
            ToastrPngk({ msg: "Enter Coupon Code", type: "error", id: "0011usdt" })
        }
       
    }
    return (
        <DialogueModal close={() => useModalState.setState({ redeem: false })} openModal={RedStatus}>
            <div className='w-[5rem] p-[.2rem] pt-[.3rem] flex flex-col gap-[.1rem]' style={{ fontSize: "initial" }}>
                <div className='flex justify-between'>
                    <span style={{ color: color.text4 }} className='text-[.18rem]'> {t("ts1284", { ns: "ts" })}</span>
                    <button className='px-[.1rem] p-[.05rem] rounded-[.1rem] text-[.14rem]' style={{ color: color.text4,background:color.forGround }}>{t("ts1287", { ns: "ts" })}</button>
                </div>
                <div className='w-full border rounded-[.08rem] my-[.1rem]'>
                    <input ref={codeRef} className="bg-transparent outline-none w-full p-[.1rem] text-white" placeholder={t("ts1284", { ns: "ts" })} type="text" />
                </div>
                <div>
                    <button onClick={redemCoupon} className='p-[.1rem] rounded-[.1rem] text-[.18rem] w-full' style={{ color: color.text4,background:color.forGround }}>{t("ts1288", { ns: "ts" })}</button>
                </div>
                <div className='w-full flex items-center justify-center'>
                    <span style={{ color: color.text4 }}> {t("ts1286", { ns: "ts" })}</span>
                </div>
                <div className='flex justify-around'>
                    <img className='w-[.5rem]' src="/supportImages/facebook.png" alt="" />
                    <img className='w-[.5rem]' src="/supportImages/instagram.png" alt="" />
                    <img className='w-[.5rem]' src="/supportImages/whatsapp.png" alt="" />
                    <img className='w-[.5rem]' src="/footerImage/16.png" alt="" />
                    <img className='w-[.5rem]' src="/supportImages/telegram.png" alt="" />
                </div>
            </div>
        </DialogueModal>
    )
}